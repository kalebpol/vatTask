﻿
namespace VatTask
{
    public class VatData
    {
        public string details;
        public string version;
        public CountryRates[] rates;
    }
}
