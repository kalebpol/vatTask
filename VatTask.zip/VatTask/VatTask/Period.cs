﻿using System;

namespace VatTask
{
    public class Period
    {
	    public DateTime effective_from;
	    public Rates rates;
    }
}
