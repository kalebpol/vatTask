﻿using System;

namespace VatTask
{
    public class Rates
    {
        public Decimal? super_reduced;
        public Decimal? reduced1;
        public Decimal? reduced2;
        public Decimal standard;
        public Decimal? parking;
    }
}
